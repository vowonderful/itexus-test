<?php
/**
 * @var array $data -> Prepared parameters
 */

?>



<div class="center">
    <h1>Are you sure you want to log out?</h1>
    <hr>
    <div class="buttons">
        <a href="#" onclick="history.back();return false;"><button class="btn-no">No</button></a>
        |
        <a href="/logout"><button class="btn-yes">Yes</button></a>
    </div>
</div>
