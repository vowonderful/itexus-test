<div class="footer">
    <div class="footer__row footer__row_center box">
        <div class="footer__left">© 2022 Mihalevich Vladimir</div>
        <div class="footer__right">Made with <span class="red">❤</span></div>
    </div>
</div>