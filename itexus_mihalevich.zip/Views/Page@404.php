<?php
/**
 * @var array $data -> Prepared parameters
 */
?>

<h1>Page Not Found</h1>

<?php include $part['menu']; ?>
<?php include $part['notify']; ?>

<div class="notify error footer center">The requested page was not found</div>

